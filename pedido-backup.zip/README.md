# Respaldo de carga de pedidos

Este repositorio contiene un sistema mínimo, funcional y listo para producción cuyo objetivo es servir como respaldo de carga de pedidos en formato Excel cuando falle la sincronización entre sistemas.  El proyecto está construido con **Node.js**, **Express** y **MySQL**, y ofrece una interfaz sencilla tanto para usuarios sin autenticación como para administradores.

## 🎯 Características

- **Subida de archivos sin login**: cualquier usuario puede elegir su sucursal, subir un archivo Excel (`.xls` o `.xlsx`) y almacenarlo en el servidor. Cada subida se registra en la base de datos con la sucursal, nombre del archivo, ruta y la fecha/hora de subida.
- **Panel de administrador**: los usuarios con rol `admin` pueden iniciar sesión para consultar una tabla con todos los archivos subidos, filtrarlos por fecha, descargar archivos individuales o descargar todos los archivos de un día en un ZIP.
- **Tecnologías**: se utilizan Express para el servidor HTTP, `multer` para gestionar la subida de archivos, `mysql2` para la conexión con MySQL, `express-session` para la autenticación básica con sesiones y `archiver` para la creación de ZIP.
- **Despliegue en Railway**: se proporciona una configuración lista para desplegar el proyecto en Railway utilizando variables de entorno para la conexión a la base de datos y el puerto de escucha.

## 🗄️ Estructura del proyecto

```
pedido-backup/
│
├── backend/              # Código del servidor Express
│   ├── server.js         # Punto de entrada del servidor
│   ├── db.js             # Configuración del pool de MySQL
│   ├── routes/           # Definición de rutas API
│   │   ├── upload.routes.js
│   │   ├── admin.routes.js
│   │   └── auth.routes.js
│   ├── controllers/      # (Reservado para lógica adicional, actualmente no usado)
│   ├── middleware/       # Middleware de autenticación
│   └── uploads/          # Carpeta donde se guardan los archivos subidos
│
├── frontend/             # Archivos estáticos servidos al navegador
│   ├── index.html        # Formulario de subida de archivos
│   ├── admin.html        # Panel de administración
│   ├── login.html        # Formulario de login
│   ├── css/
│   │   └── styles.css    # Estilos básicos
│   └── js/
│       ├── index.js      # Lógica de la página de subida
│       ├── admin.js      # Lógica del panel admin
│       └── login.js      # Lógica del login
│
├── database.sql          # Script SQL para crear las tablas e insertar el admin
├── .env.example          # Ejemplo de configuración de variables de entorno
├── package.json          # Dependencias y scripts de npm
└── README.md             # Este documento
```

## 🧰 Requisitos previos

- **Node.js** (versión 14 o superior) y **npm** instalados en tu equipo.
- **MySQL** en ejecución con permisos para crear bases de datos y tablas.
- (Opcional) Una cuenta en [Railway](https://railway.app/) si deseas desplegar el proyecto en la nube.

## 🔧 Instalación y ejecución local

1. **Clonar el repositorio** en tu máquina:

   ```bash
   git clone <url-del-repositorio>
   cd pedido-backup
   ```

2. **Crear la base de datos**. Desde tu cliente de MySQL (CLI o GUI) ejecuta el script `database.sql` para crear las tablas `uploads` y `users` e insertar el usuario administrador por defecto:

   ```sql
   SOURCE database.sql;
   ```

   El script crea un usuario admin con credenciales:

   - **Usuario**: `admin`
   - **Contraseña**: `admin123`

   > ⚠️ Las contraseñas se almacenan en texto plano únicamente por simplicidad en este ejemplo. Para un entorno real se recomienda encriptarlas con `bcrypt` u otra librería.

3. **Configurar variables de entorno**. Copia el archivo `.env.example` a `.env` y edítalo con los valores adecuados para tu entorno. Como mínimo debes ajustar la conexión a la base de datos y el secreto de sesión:

   ```bash
   cp .env.example .env
   # Edita .env con tu editor favorito
   ```

4. **Instalar dependencias** del proyecto:

   ```bash
   npm install
   ```

5. **Ejecutar el servidor** en desarrollo:

   ```bash
   npm start
   ```

   Por defecto, el servidor escuchará en el puerto definido en la variable `PORT` (3000 si no se define). Accede al portal en tu navegador en `http://localhost:3000`.

## 🗂️ Uso de la aplicación

- **Carga de archivos**: abre `http://localhost:3000` para ver el formulario de subida. Selecciona la sucursal, elige un archivo Excel y pulsa en *Subir*. Si la operación tiene éxito verás un mensaje de confirmación.
- **Acceso al panel de administrador**: visita `http://localhost:3000/login.html`, introduce las credenciales del usuario administrador y serás redirigido al panel. Desde allí podrás:
  - Filtrar los archivos por fecha (campo *Filtrar por fecha*).
  - Descargar archivos individuales mediante el enlace *Descargar* de cada fila.
  - Descargar todos los archivos de un día concreto pulsando en *Descargar todos* después de seleccionar una fecha.

## 🚀 Despliegue en Railway

Este proyecto está preparado para desplegarse en Railway de manera sencilla.

1. **Crear un nuevo proyecto** en Railway e importar este repositorio desde GitHub.
2. En la sección de **Variables**, define las siguientes variables de entorno con los valores correspondientes a tu instancia de base de datos en Railway o cualquier proveedor externo:
   - `PORT` → Puerto en el que se ejecutará la aplicación (Railway lo establece automáticamente como `PORT`).
   - `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` → Configuración de tu base de datos MySQL.
   - `SESSION_SECRET` → Una cadena aleatoria para firmar las sesiones.
3. **Configurar la base de datos**: Railway permite añadir un plugin de MySQL que crea automáticamente la base de datos. Ejecuta el script `database.sql` en esa base de datos para crear las tablas.
4. **Despliegue**: Railway detectará el archivo `package.json` y ejecutará `npm start` por defecto. Asegúrate de que el directorio `backend/uploads` sea persistente; sin embargo, en Railway los discos son efímeros y no garantizan persistencia a largo plazo, por lo que los archivos pueden perderse si la instancia se reinicia. Considera usar un almacenamiento externo si necesitas garantizar la permanencia de los archivos.

## 🔐 Consideraciones de seguridad

Este proyecto está pensado como un ejemplo mínimo y rápido de implementar. Para llevarlo a producción se recomienda:

- **Encriptar las contraseñas** en la tabla `users` con `bcrypt` u otra librería de hashing.
- **Validar y sanear las entradas** más exhaustivamente para evitar ataques de inyección y otros vectores.
- **Limitar el tamaño y tipo de archivos** de manera acorde a las necesidades del negocio.
- **Usar un almacenamiento de sesiones persistente** (por ejemplo Redis) en lugar de la memoria por defecto.
- **Proteger la carpeta de uploads** para que no sea pública si el servidor se despliega detrás de un servidor web como Nginx.

---
¡Gracias por usar este sistema de respaldo de pedidos! Esperamos que te sea de utilidad y sirva como base para proyectos más complejos.