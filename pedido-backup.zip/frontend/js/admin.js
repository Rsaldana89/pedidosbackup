// Script de la página de administración
// Carga la lista de archivos y gestiona los filtros y descargas

async function fetchUploads(date = '') {
  let url = '/api/uploads';
  if (date) {
    url += `?date=${date}`;
  }
  try {
    const response = await fetch(url);
    if (response.status === 401) {
      // Si no está autenticado, redirigir al login
      window.location.href = 'login.html';
      return;
    }
    const data = await response.json();
    const tbody = document.querySelector('#uploadsTable tbody');
    tbody.innerHTML = '';
    data.forEach((item) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${item.id}</td>
        <td>${item.sucursal}</td>
        <td>${item.filename}</td>
        <td>${new Date(item.created_at).toLocaleString()}</td>
        <td><a href="/api/download/${item.id}">Descargar</a></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Cargar todos los archivos al iniciar
  fetchUploads();
  // Evento para filtrar
  document.getElementById('filterBtn').addEventListener('click', () => {
    const date = document.getElementById('filterDate').value;
    if (date) {
      fetchUploads(date);
    } else {
      fetchUploads();
    }
  });
  // Evento para descargar todos
  document.getElementById('downloadAllBtn').addEventListener('click', () => {
    const date = document.getElementById('filterDate').value;
    if (!date) {
      alert('Selecciona una fecha para descargar todos los archivos');
      return;
    }
    window.location.href = `/api/download-all?date=${date}`;
  });
});