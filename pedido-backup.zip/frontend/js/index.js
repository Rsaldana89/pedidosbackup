// Script de la página de subida
// Maneja el envío del formulario de subida y muestra mensajes de éxito o error.

document.getElementById('uploadForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const sucursal = document.getElementById('sucursal').value;
  const fileInput = document.getElementById('file');
  const messageEl = document.getElementById('message');

  // Validaciones básicas
  if (!sucursal) {
    messageEl.textContent = 'Por favor selecciona una sucursal.';
    messageEl.style.color = 'red';
    return;
  }
  if (!fileInput.files || fileInput.files.length === 0) {
    messageEl.textContent = 'Por favor selecciona un archivo.';
    messageEl.style.color = 'red';
    return;
  }

  const formData = new FormData();
  formData.append('sucursal', sucursal);
  formData.append('file', fileInput.files[0]);

  try {
    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    const data = await response.json();
    if (response.ok) {
      messageEl.textContent = data.message;
      messageEl.style.color = 'green';
      // Reiniciar formulario
      document.getElementById('uploadForm').reset();
    } else {
      messageEl.textContent = data.message || 'Error al subir el archivo';
      messageEl.style.color = 'red';
    }
  } catch (err) {
    console.error(err);
    messageEl.textContent = 'Ocurrió un error al subir el archivo';
    messageEl.style.color = 'red';
  }
});