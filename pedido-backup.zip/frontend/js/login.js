// Script de la página de login
// Envía las credenciales al backend y redirige al panel de administración

document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const messageEl = document.getElementById('loginMessage');

  if (!username || !password) {
    messageEl.textContent = 'Ingresa usuario y contraseña';
    messageEl.style.color = 'red';
    return;
  }

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });
    const data = await response.json();
    if (response.ok) {
      // redirigir a la página de admin
      window.location.href = 'admin.html';
    } else {
      messageEl.textContent = data.message || 'Error de autenticación';
      messageEl.style.color = 'red';
    }
  } catch (err) {
    console.error(err);
    messageEl.textContent = 'Ocurrió un error en la autenticación';
    messageEl.style.color = 'red';
  }
});