-- Script de creación de base de datos para el proyecto de respaldo de pedidos
-- Crea las tablas uploads y users e inserta un usuario administrador por defecto

CREATE TABLE IF NOT EXISTS uploads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sucursal VARCHAR(255) NOT NULL,
  filename VARCHAR(255) NOT NULL,
  filepath VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'admin'
);

-- Inserta un usuario administrador por defecto. Las contraseñas se almacenan en texto plano
-- para simplificar el ejemplo; en producción se recomienda usar hashes.
INSERT INTO users (username, password, role) VALUES ('admin', 'admin123', 'admin');