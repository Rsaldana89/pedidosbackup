const express = require('express');
const path = require('path');
const archiver = require('archiver');
const db = require('../db');
const { isAuthenticated } = require('../middleware/authMiddleware');

const router = express.Router();

/*
 * Devuelve la lista de archivos subidos. Si se especifica el parámetro
 * 'date' (YYYY-MM-DD) filtra por fecha, de lo contrario devuelve
 * todos los registros ordenados de más reciente a más antiguo. Esta
 * ruta está protegida y requiere una sesión válida de administrador.
 */
router.get('/uploads', isAuthenticated, async (req, res) => {
  try {
    const { date } = req.query;
    let query = 'SELECT id, sucursal, filename, created_at FROM uploads';
    const params = [];
    if (date) {
      query += ' WHERE DATE(created_at) = ?';
      params.push(date);
    }
    query += ' ORDER BY created_at DESC';
    const [rows] = await db.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener la lista de archivos' });
  }
});

/*
 * Permite descargar un archivo individual por su ID. Busca el registro
 * en la base de datos y utiliza res.download para enviar el archivo
 * al cliente. La ruta está protegida por autenticación.
 */
router.get('/download/:id', isAuthenticated, async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.execute('SELECT * FROM uploads WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Archivo no encontrado' });
    }
    const fileRecord = rows[0];
    res.download(fileRecord.filepath, fileRecord.filename);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al descargar el archivo' });
  }
});

/*
 * Genera un archivo ZIP con todos los archivos correspondientes a una
 * fecha específica (YYYY-MM-DD). Se envía el ZIP como descarga sin
 * guardarlo en disco. La ruta está protegida por autenticación.
 */
router.get('/download-all', isAuthenticated, async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) {
      return res.status(400).json({ message: 'El parámetro date es obligatorio' });
    }
    const [rows] = await db.execute(
      'SELECT * FROM uploads WHERE DATE(created_at) = ?',
      [date]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'No hay archivos para esa fecha' });
    }
    const zipName = `archivos_${date}.zip`;
    res.setHeader('Content-Disposition', `attachment; filename=${zipName}`);
    res.setHeader('Content-Type', 'application/zip');
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.on('error', (err) => {
      throw err;
    });
    archive.pipe(res);
    rows.forEach((record) => {
      archive.file(record.filepath, { name: record.filename });
    });
    archive.finalize();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al generar el ZIP' });
  }
});

module.exports = router;