const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../db');

const router = express.Router();

/*
 * Configuración de Multer para almacenar archivos en disco. Se
 * especifica la carpeta de destino y se genera un nombre único
 * combinando la fecha actual con un identificador aleatorio.  Se
 * valida además la extensión para aceptar únicamente archivos
 * .xls y .xlsx y se limita el tamaño a 10 MB.
 */
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, unique + ext);
  }
});

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  const allowed = ['.xls', '.xlsx'];
  if (allowed.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Solo se permiten archivos Excel (.xls, .xlsx)'));
  }
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 } // 10 MB
});

// Ruta para subir un archivo. Recibe el campo 'file' y la sucursal.
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const { sucursal } = req.body;
    if (!sucursal) {
      return res.status(400).json({ message: 'La sucursal es obligatoria' });
    }
    const file = req.file;
    if (!file) {
      return res.status(400).json({ message: 'No se recibió ningún archivo' });
    }
    // Insertar registro en la base de datos
    const filename = file.filename;
    const filepath = file.path;
    await db.execute(
      'INSERT INTO uploads (sucursal, filename, filepath) VALUES (?, ?, ?)',
      [sucursal, filename, filepath]
    );
    res.json({ message: 'Archivo subido correctamente' });
  } catch (error) {
    console.error(error);
    // En caso de error al insertar, se puede eliminar el archivo subido
    // para evitar ficheros huérfanos.
    if (req.file) {
      const fs = require('fs');
      fs.unlink(req.file.path, () => {});
    }
    res.status(500).json({ message: 'Error al subir el archivo' });
  }
});

module.exports = router;