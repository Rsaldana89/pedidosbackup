const express = require('express');
const session = require('express-session');
const path = require('path');
const dotenv = require('dotenv');

// Rutas de la aplicación
const uploadRoutes = require('./routes/upload.routes');
const adminRoutes = require('./routes/admin.routes');
const authRoutes = require('./routes/auth.routes');

// Cargar variables de entorno
dotenv.config();

// Crear la aplicación de Express
const app = express();

// Middleware para parsear JSON y datos de formularios urlencoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/*
 * Configuración de sesiones.
 * Se usa para mantener la autenticación del usuario administrador.
 * Las sesiones se almacenan en memoria; para entornos de producción
 * conviene usar un almacenamiento persistente (por ejemplo Redis).
 */
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'secret',
    resave: false,
    saveUninitialized: false
  })
);

// Servir archivos estáticos del directorio frontend
app.use('/', express.static(path.join(__dirname, '../frontend')));

// Montar las rutas API bajo el prefijo /api
app.use('/api', authRoutes);
app.use('/api', uploadRoutes);
app.use('/api', adminRoutes);

// Ruta por defecto: mostrar la página de subida
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Puerto de escucha
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor iniciado en el puerto ${PORT}`);
});